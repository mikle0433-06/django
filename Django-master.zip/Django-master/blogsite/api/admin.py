from django.contrib import admin

# Зарегистрируйте свои модели здесь.
