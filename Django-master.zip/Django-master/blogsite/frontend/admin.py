from django.contrib import admin
from api.models import Blog, Post

# Register your models here.
admin.site.register(Blog)
admin.site.register(Post)